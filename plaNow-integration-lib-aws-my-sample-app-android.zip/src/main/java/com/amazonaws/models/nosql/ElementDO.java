package com.amazonaws.models.nosql;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "planow-mobilehub-717770008-Element")

public class ElementDO {
    private Double _number;
    private String _text;

    @DynamoDBHashKey(attributeName = "Number")
    @DynamoDBAttribute(attributeName = "Number")
    public Double getNumber() {
        return _number;
    }

    public void setNumber(final Double _number) {
        this._number = _number;
    }
    @DynamoDBAttribute(attributeName = "Text")
    public String getText() {
        return _text;
    }

    public void setText(final String _text) {
        this._text = _text;
    }

}
